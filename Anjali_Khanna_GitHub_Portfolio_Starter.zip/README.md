# Anjali Khanna Healthcare Project Management Portfolio

This folder is ready to use as a simple GitHub Pages website.

## Files
- `index.html` — main portfolio / project page
- `publications.html` — publications, manuscripts in preparation, abstracts, and presentations
- `styles.css` — visual formatting for both pages

## Publish with GitHub Pages

1. Sign in to GitHub.
2. Create a new **public** repository. A simple name such as `portfolio` is fine.
3. Upload `index.html`, `publications.html`, and `styles.css` to the **top level** of the repository.
4. Open the repository's **Settings**.
5. Open **Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Select the `main` branch and `/ (root)` folder, then save.
8. GitHub will provide the public website address after deployment.
9. Add that website URL to your resume and LinkedIn profile.

## Recommended additions
- Export your final resume as PDF and add it to the repository as `Anjali_Khanna_Resume.pdf`.
- Add a navigation link to that PDF from `index.html`.
- Add DOI, PubMed, journal, conference, ORCID, or Google Scholar links to publication titles where available.
- Add de-identified work samples only. Do not upload patient information, confidential dashboards, internal IRB documents, sponsor-confidential files, or proprietary institutional materials.

## Portfolio content strategy
For each project, use:
**Challenge → Role → Scope → Actions → Measurable Results → Tools/Methods**

The existing project cards can be expanded as you build the site.
